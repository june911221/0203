package controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.parser.ParserBasicInformation;

import model.Action_update;
import model.TipsDto;

public class Service_update implements Cominterface{
	
	static Service_update up = new Service_update();
	public static Service_update instance() {
		return up;
	}


	@Override
	public String showData(HttpServletRequest request, HttpServletResponse response) throws Exception {
	
		
		Action_update up = Action_update.instance(); //占쎈뼓疫뀐옙占쎈꽑 揶쏆빘猿�
		int number = Integer.parseInt(request.getParameter("number"));
		String title = new String(request.getParameter("title").getBytes("8859_1"),"UTF-8");
		String context= new String(request.getParameter("context").getBytes("8859_1"),"UTF-8");
		System.out.println("upd"+number+title+context);
		up.userupdate(number, title, context);
		System.out.println("done");
		return "updateok.jsp";
	}

}
