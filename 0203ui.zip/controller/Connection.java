package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*�������� urlpattern*/
public class Connection extends HttpServlet{
	
	@Override

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command = request.getParameter("command");
		Cominterface inter = null;
		String viewName = "";

		
		try {
			if(command.equals("select")){
				inter = Service_select.instance();
				viewName = inter.showData(request, response);
				viewName = viewName;
				request.getRequestDispatcher(viewName).forward(request, response);
			}else if(command.equals("insert")){
				inter = Service_insert.instance();
				viewName = inter.showData(request, response);
				viewName = viewName;
				request.getRequestDispatcher(viewName).forward(request, response);
			}else if(command.equals("select_one")){
				System.out.println("ppp");
				inter = Service_select_one.instance();
				System.out.println("www");
				viewName = inter.showData(request, response);
				System.out.println("eee");
				viewName = viewName;
				request.getRequestDispatcher(viewName).forward(request, response);
			}else if(command.equals("update")){
				System.out.println("qqw");
				inter = Service_update.instance();
				System.out.println("qw");
				viewName = inter.showData(request, response);
				System.out.println("wq");
				viewName = viewName;
				request.getRequestDispatcher(viewName).forward(request, response);
			}
			if(command.equals("delete")){
				inter = Service_delete.instance();
				viewName = inter.showData(request, response);
				viewName = viewName;
				request.getRequestDispatcher(viewName).forward(request, response);
			} else {
				viewName = "error.html";
				response.sendRedirect(viewName);
			}
		} catch (Exception e) {
			System.out.println("service err : " + e);
		}
	}
}
	