package controller;

import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.Action_insert;
import model.TipsDto;

public class Service_insert implements Cominterface{
	
	static Service_insert in = new Service_insert();
	public static Service_insert instance() {
		return in;
	}


	@Override
	public String showData(HttpServletRequest request, HttpServletResponse response) throws Exception {
	
		String category =new String(request.getParameter("category").getBytes("8859_1"),"UTF-8");
		String title = new String(request.getParameter("title").getBytes("8859_1"),"UTF-8");
		String writer = new String(request.getParameter("writer").getBytes("8859_1"),"UTF-8");
		String context = new String(request.getParameter("context").getBytes("8859_1"),"UTF-8");

		
		System.out.println("aa");
		Action_insert in = Action_insert.instance();
		in.userinsert(category,title,writer,context);
		
		return "insertok.jsp";
	}

}
