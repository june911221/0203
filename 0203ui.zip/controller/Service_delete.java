package controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Action_delete;
import model.TipsDto;

public class Service_delete implements Cominterface{
	
	static Service_delete del = new Service_delete();
	public static Service_delete instance() {
		return del;
	}
	@Override
	public String showData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int number = Integer.parseInt(request.getParameter("number"));
		

		System.out.println(number);
		Action_delete del = Action_delete.instance(); //占쎈뼓疫뀐옙占쎈꽑 揶쏆빘猿�
		del.userdelete(number);
		
		return "deleteok.jsp";
	}


	
	

}
