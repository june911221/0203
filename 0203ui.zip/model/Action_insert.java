package model;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import model.Action_insert;
import mybatis.SqlMapConfig;

public class Action_insert {
	static Action_insert in = new Action_insert();
	public static Action_insert instance(){
		return in;
}
	private SqlSessionFactory factory = SqlMapConfig.getSqlSession(); //Map.java 占쎈솁占쎌뵬占쎌뱽 筌≪뼚釉섓옙�긾
	
	public void userinsert(String category, String title, String writer, String context){

		
		TipsDto dto = new TipsDto();

		dto.setCategory(category);
		dto.setTitle(title);
		dto.setWriter(writer);
		dto.setContext(context);

		
		System.out.println("ff");
		
		
		SqlSession sqlSession = factory.openSession();
		sqlSession.insert("insert_tips",dto);
	    sqlSession.commit();
		sqlSession.close();
		
	}

	
}