package model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import model.Action_delete;
import mybatis.SqlMapConfig;

public class Action_delete {
	static Action_delete del = new Action_delete();
	public static Action_delete instance(){
		return del;
}
		
private SqlSessionFactory factory = SqlMapConfig.getSqlSession(); //Map.java 占쎈솁占쎌뵬占쎌뱽 筌≪뼚釉섓옙�긾
	
	public void userdelete(int number){		
		TipsDto dto = new TipsDto();
		dto.setNumber(number);
		
		System.out.println(number);
		SqlSession sqlSession = factory.openSession();
		sqlSession.delete("delete_tips",dto);//mapper占쎈퓠占쎄퐣 筌욑옙占쎌젟占쎈립 id 占쎄퐫占쎈선雅뚯눊由�
		System.out.println(dto.writer);
	    sqlSession.commit();
		sqlSession.close();
			
		}	
	}
