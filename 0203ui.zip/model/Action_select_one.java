package model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import mybatis.SqlMapConfig;

public class Action_select_one {


			static Action_select_one selectone = new Action_select_one();
			public static Action_select_one instance(){
				return selectone;
			}


			private SqlSessionFactory factory = SqlMapConfig.getSqlSession();//Map.java ������ ã�ƿ�

			public List<TipsDto> select_one(int number){
				List<TipsDto> list = null;
				System.out.println(number+"sdaf");
				SqlSession sqlSession = factory.openSession();
				list = sqlSession.selectList("select_one",number);//mapper���� ������ id �־��ֱ�
				System.out.println("oe"+list.size());
				sqlSession.close();
				return list;
			}
		}



