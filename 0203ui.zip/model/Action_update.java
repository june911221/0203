package model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import model.Action_update;
import mybatis.SqlMapConfig;

public class Action_update {
	static Action_update up = new Action_update();
	public static Action_update instance(){
		return up;
}
	private SqlSessionFactory factory = SqlMapConfig.getSqlSession(); //Map.java 占쎈솁占쎌뵬占쎌뱽 筌≪뼚釉섓옙�긾
	
	public void userupdate(int number, String title, String context){

		
		TipsDto dto = new TipsDto();
		dto.setNumber(number);
		dto.setTitle(title);
		dto.setContext(context);

		
		System.out.println(title);
		SqlSession sqlSession = factory.openSession();
		sqlSession.update("update_tips",dto);//mapper占쎈퓠占쎄퐣 筌욑옙占쎌젟占쎈립 id 占쎄퐫占쎈선雅뚯눊由�
	    sqlSession.commit();
		sqlSession.close();
		
	}
}