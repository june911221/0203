package model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import mybatis.SqlMapConfig;

public class Action_select {

		static Action_select select = new Action_select();
		public static Action_select instance(){
			return select;
		}


		private SqlSessionFactory factory = SqlMapConfig.getSqlSession();//Map.java ������ ã�ƿ�

		public List<TipsDto> select_tips(){
			List<TipsDto> list = null;
			SqlSession sqlSession = factory.openSession();
			list = sqlSession.selectList("select_tips");//mapper���� ������ id �־��ֱ�
			System.out.println("aa"+list.size());
			sqlSession.close();
			return list;
		}
	}

